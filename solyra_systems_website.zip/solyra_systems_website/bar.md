# SOLYRA SYSTEMS LTD — Design Bar

Reference pages inspected: [Linear homepage](https://linear.app/) and [Stripe homepage](https://stripe.com/). These are benchmarks for product-led visual clarity and business-focused conversion structure, not templates to copy.

1. **Hero hierarchy:** At desktop, the first screen uses a left-aligned headline and short supporting paragraph with a single clear primary CTA; a single product/workflow visual carries the right side. No unsupported company metrics or client proof.
2. **Alignment anchors:** Header content, hero copy, section headings, and CTA/footer content align to one centered max-width container. The hero uses a two-column grid on wide screens and stacks cleanly below tablet widths.
3. **Restrained palette:** Near-black/graphite surfaces and off-white type dominate; one mint/cyan accent is reserved for primary actions, focus, and meaningful interface details. No ambient purple glows or decorative floating badges.
4. **Typography rhythm:** Compact navigation and metadata; large editorial headline; section headings clearly subordinate to the hero; body copy remains readable and limited to comfortable line lengths.
5. **Section composition:** Services use an editorial, line-separated layout instead of a wall of identical rounded cards. The process is shown once as a single numbered timeline, with one consistent vertical axis and no looping or diagonal arrows.
6. **Purposeful motion:** The interface illustration uses a short entrance and chart-line draw; section reveals are subtle and sequenced. No continuous floating elements. All motion respects `prefers-reduced-motion` and essential content stays visible if JavaScript fails.
7. **Responsive and launch honesty:** At approximately 1440, 768, and 390 CSS pixels, preserve alignment, prevent horizontal overflow and text collisions, and stack form fields cleanly. Do not invent metrics, clients, testimonials, contact details, or claim an unconnected form is live.

Observed qualitative mechanisms are grounded in the live pages; numeric spacing values in the implementation are design choices, not measurements attributed to the references.
